﻿
namespace Odev
{
    partial class Giris
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Giris));
            this.yuklemeTimer = new System.Windows.Forms.Timer(this.components);
            this.ilerlemeYazi = new System.Windows.Forms.Label();
            this.ilerlemeCubugu = new CircularProgressBar.CircularProgressBar();
            this.loading = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // yuklemeTimer
            // 
            this.yuklemeTimer.Enabled = true;
            this.yuklemeTimer.Tick += new System.EventHandler(this.yuklemeTimer_Tick);
            // 
            // ilerlemeYazi
            // 
            this.ilerlemeYazi.AutoSize = true;
            this.ilerlemeYazi.BackColor = System.Drawing.Color.Transparent;
            this.ilerlemeYazi.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ilerlemeYazi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(213)))), ((int)(((byte)(219)))));
            this.ilerlemeYazi.Location = new System.Drawing.Point(386, 334);
            this.ilerlemeYazi.Name = "ilerlemeYazi";
            this.ilerlemeYazi.Size = new System.Drawing.Size(0, 23);
            this.ilerlemeYazi.TabIndex = 2;
            this.ilerlemeYazi.Click += new System.EventHandler(this.ilerlemeYazi_Click);
            // 
            // ilerlemeCubugu
            // 
            this.ilerlemeCubugu.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.ilerlemeCubugu.AnimationSpeed = 500;
            this.ilerlemeCubugu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ilerlemeCubugu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ilerlemeCubugu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ilerlemeCubugu.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ilerlemeCubugu.InnerMargin = 2;
            this.ilerlemeCubugu.InnerWidth = -1;
            this.ilerlemeCubugu.Location = new System.Drawing.Point(281, 93);
            this.ilerlemeCubugu.MarqueeAnimationSpeed = 2000;
            this.ilerlemeCubugu.Name = "ilerlemeCubugu";
            this.ilerlemeCubugu.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(28)))), ((int)(((byte)(43)))));
            this.ilerlemeCubugu.OuterMargin = -25;
            this.ilerlemeCubugu.OuterWidth = 26;
            this.ilerlemeCubugu.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(213)))), ((int)(((byte)(219)))));
            this.ilerlemeCubugu.ProgressWidth = 6;
            this.ilerlemeCubugu.SecondaryFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ilerlemeCubugu.Size = new System.Drawing.Size(240, 238);
            this.ilerlemeCubugu.StartAngle = 270;
            this.ilerlemeCubugu.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.ilerlemeCubugu.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.ilerlemeCubugu.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.ilerlemeCubugu.SubscriptText = "";
            this.ilerlemeCubugu.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.ilerlemeCubugu.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.ilerlemeCubugu.SuperscriptText = "";
            this.ilerlemeCubugu.TabIndex = 3;
            this.ilerlemeCubugu.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.ilerlemeCubugu.Value = 68;
            // 
            // loading
            // 
            this.loading.AutoSize = true;
            this.loading.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.loading.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(213)))), ((int)(((byte)(219)))));
            this.loading.Location = new System.Drawing.Point(345, 197);
            this.loading.Name = "loading";
            this.loading.Size = new System.Drawing.Size(116, 23);
            this.loading.TabIndex = 4;
            this.loading.Text = "Yükleniyor..";
            // 
            // Giris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.loading);
            this.Controls.Add(this.ilerlemeCubugu);
            this.Controls.Add(this.ilerlemeYazi);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Giris";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Loading";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer yuklemeTimer;
        private System.Windows.Forms.Label ilerlemeYazi;
        private CircularProgressBar.CircularProgressBar ilerlemeCubugu;
        private System.Windows.Forms.Label loading;
    }
}

