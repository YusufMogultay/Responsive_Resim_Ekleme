﻿
namespace Odev
{
    partial class anaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(anaForm));
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.dosyaIslemleri = new System.Windows.Forms.ToolStripMenuItem();
            this.dosyaAc = new System.Windows.Forms.ToolStripMenuItem();
            this.kapatTemizleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resimListe = new System.Windows.Forms.ImageList(this.components);
            this.cerceveAna = new System.Windows.Forms.TableLayoutPanel();
            this.resimKutu134 = new System.Windows.Forms.PictureBox();
            this.resimKutu133 = new System.Windows.Forms.PictureBox();
            this.resimKutu136 = new System.Windows.Forms.PictureBox();
            this.resimKutu135 = new System.Windows.Forms.PictureBox();
            this.resimKutu130 = new System.Windows.Forms.PictureBox();
            this.resimKutu129 = new System.Windows.Forms.PictureBox();
            this.resimKutu132 = new System.Windows.Forms.PictureBox();
            this.resimKutu131 = new System.Windows.Forms.PictureBox();
            this.resimKutu142 = new System.Windows.Forms.PictureBox();
            this.resimKutu141 = new System.Windows.Forms.PictureBox();
            this.resimKutu144 = new System.Windows.Forms.PictureBox();
            this.resimKutu143 = new System.Windows.Forms.PictureBox();
            this.resimKutu138 = new System.Windows.Forms.PictureBox();
            this.resimKutu137 = new System.Windows.Forms.PictureBox();
            this.resimKutu140 = new System.Windows.Forms.PictureBox();
            this.resimKutu139 = new System.Windows.Forms.PictureBox();
            this.resimKutu1 = new System.Windows.Forms.PictureBox();
            this.resimKutu2 = new System.Windows.Forms.PictureBox();
            this.resimKutu3 = new System.Windows.Forms.PictureBox();
            this.resimKutu4 = new System.Windows.Forms.PictureBox();
            this.resimKutu5 = new System.Windows.Forms.PictureBox();
            this.resimKutu6 = new System.Windows.Forms.PictureBox();
            this.resimKutu7 = new System.Windows.Forms.PictureBox();
            this.resimKutu8 = new System.Windows.Forms.PictureBox();
            this.resimKutu9 = new System.Windows.Forms.PictureBox();
            this.resimKutu10 = new System.Windows.Forms.PictureBox();
            this.resimKutu11 = new System.Windows.Forms.PictureBox();
            this.resimKutu12 = new System.Windows.Forms.PictureBox();
            this.resimKutu13 = new System.Windows.Forms.PictureBox();
            this.resimKutu14 = new System.Windows.Forms.PictureBox();
            this.resimKutu15 = new System.Windows.Forms.PictureBox();
            this.resimKutu16 = new System.Windows.Forms.PictureBox();
            this.resimKutu17 = new System.Windows.Forms.PictureBox();
            this.resimKutu18 = new System.Windows.Forms.PictureBox();
            this.resimKutu19 = new System.Windows.Forms.PictureBox();
            this.resimKutu20 = new System.Windows.Forms.PictureBox();
            this.resimKutu21 = new System.Windows.Forms.PictureBox();
            this.resimKutu22 = new System.Windows.Forms.PictureBox();
            this.resimKutu23 = new System.Windows.Forms.PictureBox();
            this.resimKutu24 = new System.Windows.Forms.PictureBox();
            this.resimKutu25 = new System.Windows.Forms.PictureBox();
            this.resimKutu26 = new System.Windows.Forms.PictureBox();
            this.resimKutu27 = new System.Windows.Forms.PictureBox();
            this.resimKutu28 = new System.Windows.Forms.PictureBox();
            this.resimKutu29 = new System.Windows.Forms.PictureBox();
            this.resimKutu30 = new System.Windows.Forms.PictureBox();
            this.resimKutu31 = new System.Windows.Forms.PictureBox();
            this.resimKutu32 = new System.Windows.Forms.PictureBox();
            this.resimKutu33 = new System.Windows.Forms.PictureBox();
            this.resimKutu34 = new System.Windows.Forms.PictureBox();
            this.resimKutu35 = new System.Windows.Forms.PictureBox();
            this.resimKutu36 = new System.Windows.Forms.PictureBox();
            this.resimKutu37 = new System.Windows.Forms.PictureBox();
            this.resimKutu38 = new System.Windows.Forms.PictureBox();
            this.resimKutu39 = new System.Windows.Forms.PictureBox();
            this.resimKutu40 = new System.Windows.Forms.PictureBox();
            this.resimKutu41 = new System.Windows.Forms.PictureBox();
            this.resimKutu42 = new System.Windows.Forms.PictureBox();
            this.resimKutu43 = new System.Windows.Forms.PictureBox();
            this.resimKutu44 = new System.Windows.Forms.PictureBox();
            this.resimKutu45 = new System.Windows.Forms.PictureBox();
            this.resimKutu46 = new System.Windows.Forms.PictureBox();
            this.resimKutu47 = new System.Windows.Forms.PictureBox();
            this.resimKutu48 = new System.Windows.Forms.PictureBox();
            this.resimKutu49 = new System.Windows.Forms.PictureBox();
            this.resimKutu50 = new System.Windows.Forms.PictureBox();
            this.resimKutu51 = new System.Windows.Forms.PictureBox();
            this.resimKutu52 = new System.Windows.Forms.PictureBox();
            this.resimKutu53 = new System.Windows.Forms.PictureBox();
            this.resimKutu54 = new System.Windows.Forms.PictureBox();
            this.resimKutu55 = new System.Windows.Forms.PictureBox();
            this.resimKutu56 = new System.Windows.Forms.PictureBox();
            this.resimKutu57 = new System.Windows.Forms.PictureBox();
            this.resimKutu58 = new System.Windows.Forms.PictureBox();
            this.resimKutu59 = new System.Windows.Forms.PictureBox();
            this.resimKutu60 = new System.Windows.Forms.PictureBox();
            this.resimKutu61 = new System.Windows.Forms.PictureBox();
            this.resimKutu62 = new System.Windows.Forms.PictureBox();
            this.resimKutu63 = new System.Windows.Forms.PictureBox();
            this.resimKutu64 = new System.Windows.Forms.PictureBox();
            this.resimKutu65 = new System.Windows.Forms.PictureBox();
            this.resimKutu66 = new System.Windows.Forms.PictureBox();
            this.resimKutu67 = new System.Windows.Forms.PictureBox();
            this.resimKutu68 = new System.Windows.Forms.PictureBox();
            this.resimKutu69 = new System.Windows.Forms.PictureBox();
            this.resimKutu70 = new System.Windows.Forms.PictureBox();
            this.resimKutu71 = new System.Windows.Forms.PictureBox();
            this.resimKutu72 = new System.Windows.Forms.PictureBox();
            this.resimKutu73 = new System.Windows.Forms.PictureBox();
            this.resimKutu74 = new System.Windows.Forms.PictureBox();
            this.resimKutu75 = new System.Windows.Forms.PictureBox();
            this.resimKutu76 = new System.Windows.Forms.PictureBox();
            this.resimKutu77 = new System.Windows.Forms.PictureBox();
            this.resimKutu78 = new System.Windows.Forms.PictureBox();
            this.resimKutu79 = new System.Windows.Forms.PictureBox();
            this.resimKutu80 = new System.Windows.Forms.PictureBox();
            this.resimKutu81 = new System.Windows.Forms.PictureBox();
            this.resimKutu82 = new System.Windows.Forms.PictureBox();
            this.resimKutu83 = new System.Windows.Forms.PictureBox();
            this.resimKutu84 = new System.Windows.Forms.PictureBox();
            this.resimKutu85 = new System.Windows.Forms.PictureBox();
            this.resimKutu86 = new System.Windows.Forms.PictureBox();
            this.resimKutu87 = new System.Windows.Forms.PictureBox();
            this.resimKutu88 = new System.Windows.Forms.PictureBox();
            this.resimKutu89 = new System.Windows.Forms.PictureBox();
            this.resimKutu90 = new System.Windows.Forms.PictureBox();
            this.resimKutu91 = new System.Windows.Forms.PictureBox();
            this.resimKutu92 = new System.Windows.Forms.PictureBox();
            this.resimKutu93 = new System.Windows.Forms.PictureBox();
            this.resimKutu94 = new System.Windows.Forms.PictureBox();
            this.resimKutu95 = new System.Windows.Forms.PictureBox();
            this.resimKutu96 = new System.Windows.Forms.PictureBox();
            this.resimKutu97 = new System.Windows.Forms.PictureBox();
            this.resimKutu98 = new System.Windows.Forms.PictureBox();
            this.resimKutu99 = new System.Windows.Forms.PictureBox();
            this.resimKutu100 = new System.Windows.Forms.PictureBox();
            this.resimKutu101 = new System.Windows.Forms.PictureBox();
            this.resimKutu102 = new System.Windows.Forms.PictureBox();
            this.resimKutu103 = new System.Windows.Forms.PictureBox();
            this.resimKutu104 = new System.Windows.Forms.PictureBox();
            this.resimKutu105 = new System.Windows.Forms.PictureBox();
            this.resimKutu106 = new System.Windows.Forms.PictureBox();
            this.resimKutu107 = new System.Windows.Forms.PictureBox();
            this.resimKutu108 = new System.Windows.Forms.PictureBox();
            this.resimKutu109 = new System.Windows.Forms.PictureBox();
            this.resimKutu110 = new System.Windows.Forms.PictureBox();
            this.resimKutu111 = new System.Windows.Forms.PictureBox();
            this.resimKutu112 = new System.Windows.Forms.PictureBox();
            this.resimKutu113 = new System.Windows.Forms.PictureBox();
            this.resimKutu114 = new System.Windows.Forms.PictureBox();
            this.resimKutu115 = new System.Windows.Forms.PictureBox();
            this.resimKutu116 = new System.Windows.Forms.PictureBox();
            this.resimKutu117 = new System.Windows.Forms.PictureBox();
            this.resimKutu118 = new System.Windows.Forms.PictureBox();
            this.resimKutu119 = new System.Windows.Forms.PictureBox();
            this.resimKutu120 = new System.Windows.Forms.PictureBox();
            this.resimKutu121 = new System.Windows.Forms.PictureBox();
            this.resimKutu122 = new System.Windows.Forms.PictureBox();
            this.resimKutu123 = new System.Windows.Forms.PictureBox();
            this.resimKutu124 = new System.Windows.Forms.PictureBox();
            this.resimKutu125 = new System.Windows.Forms.PictureBox();
            this.resimKutu126 = new System.Windows.Forms.PictureBox();
            this.resimKutu127 = new System.Windows.Forms.PictureBox();
            this.resimKutu128 = new System.Windows.Forms.PictureBox();
            this.Menu.SuspendLayout();
            this.cerceveAna.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu136)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu130)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu141)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu140)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu128)).BeginInit();
            this.SuspendLayout();
            // 
            // Menu
            // 
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaIslemleri});
            this.Menu.Location = new System.Drawing.Point(0, 0);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(1478, 29);
            this.Menu.TabIndex = 0;
            this.Menu.Text = "Ust Menu";
            this.Menu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.Menu_ItemClicked);
            // 
            // dosyaIslemleri
            // 
            this.dosyaIslemleri.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaAc,
            this.kapatTemizleToolStripMenuItem});
            this.dosyaIslemleri.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dosyaIslemleri.Image = ((System.Drawing.Image)(resources.GetObject("dosyaIslemleri.Image")));
            this.dosyaIslemleri.Name = "dosyaIslemleri";
            this.dosyaIslemleri.Size = new System.Drawing.Size(85, 25);
            this.dosyaIslemleri.Text = "Dosya";
            // 
            // dosyaAc
            // 
            this.dosyaAc.Name = "dosyaAc";
            this.dosyaAc.Size = new System.Drawing.Size(136, 26);
            this.dosyaAc.Text = "Aç";
            this.dosyaAc.Click += new System.EventHandler(this.açToolStripMenuItem_Click);
            // 
            // kapatTemizleToolStripMenuItem
            // 
            this.kapatTemizleToolStripMenuItem.Name = "kapatTemizleToolStripMenuItem";
            this.kapatTemizleToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.kapatTemizleToolStripMenuItem.Text = "Temizle";
            this.kapatTemizleToolStripMenuItem.Click += new System.EventHandler(this.kapatTemizleToolStripMenuItem_Click);
            // 
            // resimListe
            // 
            this.resimListe.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
            this.resimListe.ImageSize = new System.Drawing.Size(99, 80);
            this.resimListe.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // cerceveAna
            // 
            this.cerceveAna.BackColor = System.Drawing.Color.Transparent;
            this.cerceveAna.ColumnCount = 16;
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.250273F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.249648F));
            this.cerceveAna.Controls.Add(this.resimKutu134, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu133, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu136, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu135, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu130, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu129, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu132, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu131, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu142, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu141, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu144, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu143, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu138, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu137, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu140, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu139, 0, 8);
            this.cerceveAna.Controls.Add(this.resimKutu1, 0, 0);
            this.cerceveAna.Controls.Add(this.resimKutu2, 1, 0);
            this.cerceveAna.Controls.Add(this.resimKutu3, 2, 0);
            this.cerceveAna.Controls.Add(this.resimKutu4, 3, 0);
            this.cerceveAna.Controls.Add(this.resimKutu5, 4, 0);
            this.cerceveAna.Controls.Add(this.resimKutu6, 5, 0);
            this.cerceveAna.Controls.Add(this.resimKutu7, 6, 0);
            this.cerceveAna.Controls.Add(this.resimKutu8, 7, 0);
            this.cerceveAna.Controls.Add(this.resimKutu9, 8, 0);
            this.cerceveAna.Controls.Add(this.resimKutu10, 9, 0);
            this.cerceveAna.Controls.Add(this.resimKutu11, 10, 0);
            this.cerceveAna.Controls.Add(this.resimKutu12, 11, 0);
            this.cerceveAna.Controls.Add(this.resimKutu13, 12, 0);
            this.cerceveAna.Controls.Add(this.resimKutu14, 13, 0);
            this.cerceveAna.Controls.Add(this.resimKutu15, 14, 0);
            this.cerceveAna.Controls.Add(this.resimKutu16, 15, 0);
            this.cerceveAna.Controls.Add(this.resimKutu17, 0, 1);
            this.cerceveAna.Controls.Add(this.resimKutu18, 1, 1);
            this.cerceveAna.Controls.Add(this.resimKutu19, 2, 1);
            this.cerceveAna.Controls.Add(this.resimKutu20, 3, 1);
            this.cerceveAna.Controls.Add(this.resimKutu21, 4, 1);
            this.cerceveAna.Controls.Add(this.resimKutu22, 5, 1);
            this.cerceveAna.Controls.Add(this.resimKutu23, 6, 1);
            this.cerceveAna.Controls.Add(this.resimKutu24, 7, 1);
            this.cerceveAna.Controls.Add(this.resimKutu25, 8, 1);
            this.cerceveAna.Controls.Add(this.resimKutu26, 9, 1);
            this.cerceveAna.Controls.Add(this.resimKutu27, 10, 1);
            this.cerceveAna.Controls.Add(this.resimKutu28, 11, 1);
            this.cerceveAna.Controls.Add(this.resimKutu29, 12, 1);
            this.cerceveAna.Controls.Add(this.resimKutu30, 13, 1);
            this.cerceveAna.Controls.Add(this.resimKutu31, 14, 1);
            this.cerceveAna.Controls.Add(this.resimKutu32, 15, 1);
            this.cerceveAna.Controls.Add(this.resimKutu33, 0, 2);
            this.cerceveAna.Controls.Add(this.resimKutu34, 1, 2);
            this.cerceveAna.Controls.Add(this.resimKutu35, 2, 2);
            this.cerceveAna.Controls.Add(this.resimKutu36, 3, 2);
            this.cerceveAna.Controls.Add(this.resimKutu37, 4, 2);
            this.cerceveAna.Controls.Add(this.resimKutu38, 5, 2);
            this.cerceveAna.Controls.Add(this.resimKutu39, 6, 2);
            this.cerceveAna.Controls.Add(this.resimKutu40, 7, 2);
            this.cerceveAna.Controls.Add(this.resimKutu41, 8, 2);
            this.cerceveAna.Controls.Add(this.resimKutu42, 9, 2);
            this.cerceveAna.Controls.Add(this.resimKutu43, 10, 2);
            this.cerceveAna.Controls.Add(this.resimKutu44, 11, 2);
            this.cerceveAna.Controls.Add(this.resimKutu45, 12, 2);
            this.cerceveAna.Controls.Add(this.resimKutu46, 13, 2);
            this.cerceveAna.Controls.Add(this.resimKutu47, 14, 2);
            this.cerceveAna.Controls.Add(this.resimKutu48, 15, 2);
            this.cerceveAna.Controls.Add(this.resimKutu49, 0, 3);
            this.cerceveAna.Controls.Add(this.resimKutu50, 1, 3);
            this.cerceveAna.Controls.Add(this.resimKutu51, 2, 3);
            this.cerceveAna.Controls.Add(this.resimKutu52, 3, 3);
            this.cerceveAna.Controls.Add(this.resimKutu53, 4, 3);
            this.cerceveAna.Controls.Add(this.resimKutu54, 5, 3);
            this.cerceveAna.Controls.Add(this.resimKutu55, 6, 3);
            this.cerceveAna.Controls.Add(this.resimKutu56, 7, 3);
            this.cerceveAna.Controls.Add(this.resimKutu57, 8, 3);
            this.cerceveAna.Controls.Add(this.resimKutu58, 9, 3);
            this.cerceveAna.Controls.Add(this.resimKutu59, 10, 3);
            this.cerceveAna.Controls.Add(this.resimKutu60, 11, 3);
            this.cerceveAna.Controls.Add(this.resimKutu61, 12, 3);
            this.cerceveAna.Controls.Add(this.resimKutu62, 13, 3);
            this.cerceveAna.Controls.Add(this.resimKutu63, 14, 3);
            this.cerceveAna.Controls.Add(this.resimKutu64, 15, 3);
            this.cerceveAna.Controls.Add(this.resimKutu65, 0, 4);
            this.cerceveAna.Controls.Add(this.resimKutu66, 1, 4);
            this.cerceveAna.Controls.Add(this.resimKutu67, 2, 4);
            this.cerceveAna.Controls.Add(this.resimKutu68, 3, 4);
            this.cerceveAna.Controls.Add(this.resimKutu69, 4, 4);
            this.cerceveAna.Controls.Add(this.resimKutu70, 5, 4);
            this.cerceveAna.Controls.Add(this.resimKutu71, 6, 4);
            this.cerceveAna.Controls.Add(this.resimKutu72, 7, 4);
            this.cerceveAna.Controls.Add(this.resimKutu73, 8, 4);
            this.cerceveAna.Controls.Add(this.resimKutu74, 9, 4);
            this.cerceveAna.Controls.Add(this.resimKutu75, 10, 4);
            this.cerceveAna.Controls.Add(this.resimKutu76, 11, 4);
            this.cerceveAna.Controls.Add(this.resimKutu77, 12, 4);
            this.cerceveAna.Controls.Add(this.resimKutu78, 13, 4);
            this.cerceveAna.Controls.Add(this.resimKutu79, 14, 4);
            this.cerceveAna.Controls.Add(this.resimKutu80, 15, 4);
            this.cerceveAna.Controls.Add(this.resimKutu81, 0, 5);
            this.cerceveAna.Controls.Add(this.resimKutu82, 1, 5);
            this.cerceveAna.Controls.Add(this.resimKutu83, 2, 5);
            this.cerceveAna.Controls.Add(this.resimKutu84, 3, 5);
            this.cerceveAna.Controls.Add(this.resimKutu85, 4, 5);
            this.cerceveAna.Controls.Add(this.resimKutu86, 5, 5);
            this.cerceveAna.Controls.Add(this.resimKutu87, 6, 5);
            this.cerceveAna.Controls.Add(this.resimKutu88, 7, 5);
            this.cerceveAna.Controls.Add(this.resimKutu89, 8, 5);
            this.cerceveAna.Controls.Add(this.resimKutu90, 9, 5);
            this.cerceveAna.Controls.Add(this.resimKutu91, 10, 5);
            this.cerceveAna.Controls.Add(this.resimKutu92, 11, 5);
            this.cerceveAna.Controls.Add(this.resimKutu93, 12, 5);
            this.cerceveAna.Controls.Add(this.resimKutu94, 13, 5);
            this.cerceveAna.Controls.Add(this.resimKutu95, 14, 5);
            this.cerceveAna.Controls.Add(this.resimKutu96, 15, 5);
            this.cerceveAna.Controls.Add(this.resimKutu97, 0, 6);
            this.cerceveAna.Controls.Add(this.resimKutu98, 1, 6);
            this.cerceveAna.Controls.Add(this.resimKutu99, 2, 6);
            this.cerceveAna.Controls.Add(this.resimKutu100, 3, 6);
            this.cerceveAna.Controls.Add(this.resimKutu101, 4, 6);
            this.cerceveAna.Controls.Add(this.resimKutu102, 5, 6);
            this.cerceveAna.Controls.Add(this.resimKutu103, 6, 6);
            this.cerceveAna.Controls.Add(this.resimKutu104, 7, 6);
            this.cerceveAna.Controls.Add(this.resimKutu105, 8, 6);
            this.cerceveAna.Controls.Add(this.resimKutu106, 9, 6);
            this.cerceveAna.Controls.Add(this.resimKutu107, 10, 6);
            this.cerceveAna.Controls.Add(this.resimKutu108, 11, 6);
            this.cerceveAna.Controls.Add(this.resimKutu109, 12, 6);
            this.cerceveAna.Controls.Add(this.resimKutu110, 13, 6);
            this.cerceveAna.Controls.Add(this.resimKutu111, 14, 6);
            this.cerceveAna.Controls.Add(this.resimKutu112, 15, 6);
            this.cerceveAna.Controls.Add(this.resimKutu113, 0, 7);
            this.cerceveAna.Controls.Add(this.resimKutu114, 1, 7);
            this.cerceveAna.Controls.Add(this.resimKutu115, 2, 7);
            this.cerceveAna.Controls.Add(this.resimKutu116, 3, 7);
            this.cerceveAna.Controls.Add(this.resimKutu117, 4, 7);
            this.cerceveAna.Controls.Add(this.resimKutu118, 5, 7);
            this.cerceveAna.Controls.Add(this.resimKutu119, 6, 7);
            this.cerceveAna.Controls.Add(this.resimKutu120, 7, 7);
            this.cerceveAna.Controls.Add(this.resimKutu121, 8, 7);
            this.cerceveAna.Controls.Add(this.resimKutu122, 9, 7);
            this.cerceveAna.Controls.Add(this.resimKutu123, 10, 7);
            this.cerceveAna.Controls.Add(this.resimKutu124, 11, 7);
            this.cerceveAna.Controls.Add(this.resimKutu125, 12, 7);
            this.cerceveAna.Controls.Add(this.resimKutu126, 13, 7);
            this.cerceveAna.Controls.Add(this.resimKutu127, 14, 7);
            this.cerceveAna.Controls.Add(this.resimKutu128, 15, 7);
            this.cerceveAna.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cerceveAna.Location = new System.Drawing.Point(0, 29);
            this.cerceveAna.Name = "cerceveAna";
            this.cerceveAna.RowCount = 9;
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11037F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11037F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11037F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11037F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11037F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11037F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11259F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11259F));
            this.cerceveAna.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11259F));
            this.cerceveAna.Size = new System.Drawing.Size(1478, 733);
            this.cerceveAna.TabIndex = 1;
            // 
            // resimKutu134
            // 
            this.resimKutu134.BackColor = System.Drawing.Color.White;
            this.resimKutu134.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu134.Location = new System.Drawing.Point(463, 651);
            this.resimKutu134.Name = "resimKutu134";
            this.resimKutu134.Size = new System.Drawing.Size(86, 79);
            this.resimKutu134.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu134.TabIndex = 360;
            this.resimKutu134.TabStop = false;
            // 
            // resimKutu133
            // 
            this.resimKutu133.BackColor = System.Drawing.Color.White;
            this.resimKutu133.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu133.Location = new System.Drawing.Point(371, 651);
            this.resimKutu133.Name = "resimKutu133";
            this.resimKutu133.Size = new System.Drawing.Size(86, 79);
            this.resimKutu133.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu133.TabIndex = 359;
            this.resimKutu133.TabStop = false;
            // 
            // resimKutu136
            // 
            this.resimKutu136.BackColor = System.Drawing.Color.White;
            this.resimKutu136.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu136.Location = new System.Drawing.Point(647, 651);
            this.resimKutu136.Name = "resimKutu136";
            this.resimKutu136.Size = new System.Drawing.Size(86, 79);
            this.resimKutu136.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu136.TabIndex = 358;
            this.resimKutu136.TabStop = false;
            // 
            // resimKutu135
            // 
            this.resimKutu135.BackColor = System.Drawing.Color.White;
            this.resimKutu135.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu135.Location = new System.Drawing.Point(555, 651);
            this.resimKutu135.Name = "resimKutu135";
            this.resimKutu135.Size = new System.Drawing.Size(86, 79);
            this.resimKutu135.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu135.TabIndex = 357;
            this.resimKutu135.TabStop = false;
            // 
            // resimKutu130
            // 
            this.resimKutu130.BackColor = System.Drawing.Color.White;
            this.resimKutu130.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu130.Location = new System.Drawing.Point(95, 651);
            this.resimKutu130.Name = "resimKutu130";
            this.resimKutu130.Size = new System.Drawing.Size(86, 79);
            this.resimKutu130.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu130.TabIndex = 356;
            this.resimKutu130.TabStop = false;
            // 
            // resimKutu129
            // 
            this.resimKutu129.BackColor = System.Drawing.Color.White;
            this.resimKutu129.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu129.Location = new System.Drawing.Point(3, 651);
            this.resimKutu129.Name = "resimKutu129";
            this.resimKutu129.Size = new System.Drawing.Size(86, 79);
            this.resimKutu129.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu129.TabIndex = 355;
            this.resimKutu129.TabStop = false;
            // 
            // resimKutu132
            // 
            this.resimKutu132.BackColor = System.Drawing.Color.White;
            this.resimKutu132.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu132.Location = new System.Drawing.Point(279, 651);
            this.resimKutu132.Name = "resimKutu132";
            this.resimKutu132.Size = new System.Drawing.Size(86, 79);
            this.resimKutu132.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu132.TabIndex = 354;
            this.resimKutu132.TabStop = false;
            // 
            // resimKutu131
            // 
            this.resimKutu131.BackColor = System.Drawing.Color.White;
            this.resimKutu131.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu131.Location = new System.Drawing.Point(187, 651);
            this.resimKutu131.Name = "resimKutu131";
            this.resimKutu131.Size = new System.Drawing.Size(86, 79);
            this.resimKutu131.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu131.TabIndex = 353;
            this.resimKutu131.TabStop = false;
            // 
            // resimKutu142
            // 
            this.resimKutu142.BackColor = System.Drawing.Color.White;
            this.resimKutu142.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu142.Location = new System.Drawing.Point(1199, 651);
            this.resimKutu142.Name = "resimKutu142";
            this.resimKutu142.Size = new System.Drawing.Size(86, 79);
            this.resimKutu142.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu142.TabIndex = 352;
            this.resimKutu142.TabStop = false;
            // 
            // resimKutu141
            // 
            this.resimKutu141.BackColor = System.Drawing.Color.White;
            this.resimKutu141.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu141.Location = new System.Drawing.Point(1107, 651);
            this.resimKutu141.Name = "resimKutu141";
            this.resimKutu141.Size = new System.Drawing.Size(86, 79);
            this.resimKutu141.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu141.TabIndex = 351;
            this.resimKutu141.TabStop = false;
            // 
            // resimKutu144
            // 
            this.resimKutu144.BackColor = System.Drawing.Color.White;
            this.resimKutu144.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu144.Location = new System.Drawing.Point(1383, 651);
            this.resimKutu144.Name = "resimKutu144";
            this.resimKutu144.Size = new System.Drawing.Size(92, 79);
            this.resimKutu144.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu144.TabIndex = 350;
            this.resimKutu144.TabStop = false;
            // 
            // resimKutu143
            // 
            this.resimKutu143.BackColor = System.Drawing.Color.White;
            this.resimKutu143.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu143.Location = new System.Drawing.Point(1291, 651);
            this.resimKutu143.Name = "resimKutu143";
            this.resimKutu143.Size = new System.Drawing.Size(86, 79);
            this.resimKutu143.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu143.TabIndex = 349;
            this.resimKutu143.TabStop = false;
            // 
            // resimKutu138
            // 
            this.resimKutu138.BackColor = System.Drawing.Color.White;
            this.resimKutu138.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu138.Location = new System.Drawing.Point(831, 651);
            this.resimKutu138.Name = "resimKutu138";
            this.resimKutu138.Size = new System.Drawing.Size(86, 79);
            this.resimKutu138.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu138.TabIndex = 348;
            this.resimKutu138.TabStop = false;
            // 
            // resimKutu137
            // 
            this.resimKutu137.BackColor = System.Drawing.Color.White;
            this.resimKutu137.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu137.Location = new System.Drawing.Point(739, 651);
            this.resimKutu137.Name = "resimKutu137";
            this.resimKutu137.Size = new System.Drawing.Size(86, 79);
            this.resimKutu137.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu137.TabIndex = 347;
            this.resimKutu137.TabStop = false;
            // 
            // resimKutu140
            // 
            this.resimKutu140.BackColor = System.Drawing.Color.White;
            this.resimKutu140.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu140.Location = new System.Drawing.Point(1015, 651);
            this.resimKutu140.Name = "resimKutu140";
            this.resimKutu140.Size = new System.Drawing.Size(86, 79);
            this.resimKutu140.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu140.TabIndex = 346;
            this.resimKutu140.TabStop = false;
            // 
            // resimKutu139
            // 
            this.resimKutu139.BackColor = System.Drawing.Color.White;
            this.resimKutu139.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu139.Location = new System.Drawing.Point(923, 651);
            this.resimKutu139.Name = "resimKutu139";
            this.resimKutu139.Size = new System.Drawing.Size(86, 79);
            this.resimKutu139.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu139.TabIndex = 345;
            this.resimKutu139.TabStop = false;
            // 
            // resimKutu1
            // 
            this.resimKutu1.BackColor = System.Drawing.Color.White;
            this.resimKutu1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu1.Location = new System.Drawing.Point(3, 3);
            this.resimKutu1.Name = "resimKutu1";
            this.resimKutu1.Size = new System.Drawing.Size(86, 75);
            this.resimKutu1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu1.TabIndex = 217;
            this.resimKutu1.TabStop = false;
            // 
            // resimKutu2
            // 
            this.resimKutu2.BackColor = System.Drawing.Color.White;
            this.resimKutu2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu2.Location = new System.Drawing.Point(95, 3);
            this.resimKutu2.Name = "resimKutu2";
            this.resimKutu2.Size = new System.Drawing.Size(86, 75);
            this.resimKutu2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu2.TabIndex = 218;
            this.resimKutu2.TabStop = false;
            // 
            // resimKutu3
            // 
            this.resimKutu3.BackColor = System.Drawing.Color.White;
            this.resimKutu3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu3.Location = new System.Drawing.Point(187, 3);
            this.resimKutu3.Name = "resimKutu3";
            this.resimKutu3.Size = new System.Drawing.Size(86, 75);
            this.resimKutu3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu3.TabIndex = 219;
            this.resimKutu3.TabStop = false;
            // 
            // resimKutu4
            // 
            this.resimKutu4.BackColor = System.Drawing.Color.White;
            this.resimKutu4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu4.Location = new System.Drawing.Point(279, 3);
            this.resimKutu4.Name = "resimKutu4";
            this.resimKutu4.Size = new System.Drawing.Size(86, 75);
            this.resimKutu4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu4.TabIndex = 220;
            this.resimKutu4.TabStop = false;
            // 
            // resimKutu5
            // 
            this.resimKutu5.BackColor = System.Drawing.Color.White;
            this.resimKutu5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu5.Location = new System.Drawing.Point(371, 3);
            this.resimKutu5.Name = "resimKutu5";
            this.resimKutu5.Size = new System.Drawing.Size(86, 75);
            this.resimKutu5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu5.TabIndex = 221;
            this.resimKutu5.TabStop = false;
            // 
            // resimKutu6
            // 
            this.resimKutu6.BackColor = System.Drawing.Color.White;
            this.resimKutu6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu6.Location = new System.Drawing.Point(463, 3);
            this.resimKutu6.Name = "resimKutu6";
            this.resimKutu6.Size = new System.Drawing.Size(86, 75);
            this.resimKutu6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu6.TabIndex = 222;
            this.resimKutu6.TabStop = false;
            // 
            // resimKutu7
            // 
            this.resimKutu7.BackColor = System.Drawing.Color.White;
            this.resimKutu7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu7.Location = new System.Drawing.Point(555, 3);
            this.resimKutu7.Name = "resimKutu7";
            this.resimKutu7.Size = new System.Drawing.Size(86, 75);
            this.resimKutu7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu7.TabIndex = 223;
            this.resimKutu7.TabStop = false;
            // 
            // resimKutu8
            // 
            this.resimKutu8.BackColor = System.Drawing.Color.White;
            this.resimKutu8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu8.Location = new System.Drawing.Point(647, 3);
            this.resimKutu8.Name = "resimKutu8";
            this.resimKutu8.Size = new System.Drawing.Size(86, 75);
            this.resimKutu8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu8.TabIndex = 224;
            this.resimKutu8.TabStop = false;
            // 
            // resimKutu9
            // 
            this.resimKutu9.BackColor = System.Drawing.Color.White;
            this.resimKutu9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu9.Location = new System.Drawing.Point(739, 3);
            this.resimKutu9.Name = "resimKutu9";
            this.resimKutu9.Size = new System.Drawing.Size(86, 75);
            this.resimKutu9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu9.TabIndex = 225;
            this.resimKutu9.TabStop = false;
            // 
            // resimKutu10
            // 
            this.resimKutu10.BackColor = System.Drawing.Color.White;
            this.resimKutu10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu10.Location = new System.Drawing.Point(831, 3);
            this.resimKutu10.Name = "resimKutu10";
            this.resimKutu10.Size = new System.Drawing.Size(86, 75);
            this.resimKutu10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu10.TabIndex = 226;
            this.resimKutu10.TabStop = false;
            // 
            // resimKutu11
            // 
            this.resimKutu11.BackColor = System.Drawing.Color.White;
            this.resimKutu11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu11.Location = new System.Drawing.Point(923, 3);
            this.resimKutu11.Name = "resimKutu11";
            this.resimKutu11.Size = new System.Drawing.Size(86, 75);
            this.resimKutu11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu11.TabIndex = 227;
            this.resimKutu11.TabStop = false;
            // 
            // resimKutu12
            // 
            this.resimKutu12.BackColor = System.Drawing.Color.White;
            this.resimKutu12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu12.Location = new System.Drawing.Point(1015, 3);
            this.resimKutu12.Name = "resimKutu12";
            this.resimKutu12.Size = new System.Drawing.Size(86, 75);
            this.resimKutu12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu12.TabIndex = 228;
            this.resimKutu12.TabStop = false;
            // 
            // resimKutu13
            // 
            this.resimKutu13.BackColor = System.Drawing.Color.White;
            this.resimKutu13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu13.Location = new System.Drawing.Point(1107, 3);
            this.resimKutu13.Name = "resimKutu13";
            this.resimKutu13.Size = new System.Drawing.Size(86, 75);
            this.resimKutu13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu13.TabIndex = 229;
            this.resimKutu13.TabStop = false;
            // 
            // resimKutu14
            // 
            this.resimKutu14.BackColor = System.Drawing.Color.White;
            this.resimKutu14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu14.Location = new System.Drawing.Point(1199, 3);
            this.resimKutu14.Name = "resimKutu14";
            this.resimKutu14.Size = new System.Drawing.Size(86, 75);
            this.resimKutu14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu14.TabIndex = 230;
            this.resimKutu14.TabStop = false;
            // 
            // resimKutu15
            // 
            this.resimKutu15.BackColor = System.Drawing.Color.White;
            this.resimKutu15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu15.Location = new System.Drawing.Point(1291, 3);
            this.resimKutu15.Name = "resimKutu15";
            this.resimKutu15.Size = new System.Drawing.Size(86, 75);
            this.resimKutu15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu15.TabIndex = 231;
            this.resimKutu15.TabStop = false;
            // 
            // resimKutu16
            // 
            this.resimKutu16.BackColor = System.Drawing.Color.White;
            this.resimKutu16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu16.Location = new System.Drawing.Point(1383, 3);
            this.resimKutu16.Name = "resimKutu16";
            this.resimKutu16.Size = new System.Drawing.Size(92, 75);
            this.resimKutu16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu16.TabIndex = 232;
            this.resimKutu16.TabStop = false;
            // 
            // resimKutu17
            // 
            this.resimKutu17.BackColor = System.Drawing.Color.White;
            this.resimKutu17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu17.Location = new System.Drawing.Point(3, 84);
            this.resimKutu17.Name = "resimKutu17";
            this.resimKutu17.Size = new System.Drawing.Size(86, 75);
            this.resimKutu17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu17.TabIndex = 233;
            this.resimKutu17.TabStop = false;
            this.resimKutu17.Click += new System.EventHandler(this.resimKutu17_Click);
            // 
            // resimKutu18
            // 
            this.resimKutu18.BackColor = System.Drawing.Color.White;
            this.resimKutu18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu18.Location = new System.Drawing.Point(95, 84);
            this.resimKutu18.Name = "resimKutu18";
            this.resimKutu18.Size = new System.Drawing.Size(86, 75);
            this.resimKutu18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu18.TabIndex = 234;
            this.resimKutu18.TabStop = false;
            // 
            // resimKutu19
            // 
            this.resimKutu19.BackColor = System.Drawing.Color.White;
            this.resimKutu19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu19.Location = new System.Drawing.Point(187, 84);
            this.resimKutu19.Name = "resimKutu19";
            this.resimKutu19.Size = new System.Drawing.Size(86, 75);
            this.resimKutu19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu19.TabIndex = 235;
            this.resimKutu19.TabStop = false;
            // 
            // resimKutu20
            // 
            this.resimKutu20.BackColor = System.Drawing.Color.White;
            this.resimKutu20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu20.Location = new System.Drawing.Point(279, 84);
            this.resimKutu20.Name = "resimKutu20";
            this.resimKutu20.Size = new System.Drawing.Size(86, 75);
            this.resimKutu20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu20.TabIndex = 236;
            this.resimKutu20.TabStop = false;
            // 
            // resimKutu21
            // 
            this.resimKutu21.BackColor = System.Drawing.Color.White;
            this.resimKutu21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu21.Location = new System.Drawing.Point(371, 84);
            this.resimKutu21.Name = "resimKutu21";
            this.resimKutu21.Size = new System.Drawing.Size(86, 75);
            this.resimKutu21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu21.TabIndex = 237;
            this.resimKutu21.TabStop = false;
            // 
            // resimKutu22
            // 
            this.resimKutu22.BackColor = System.Drawing.Color.White;
            this.resimKutu22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu22.Location = new System.Drawing.Point(463, 84);
            this.resimKutu22.Name = "resimKutu22";
            this.resimKutu22.Size = new System.Drawing.Size(86, 75);
            this.resimKutu22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu22.TabIndex = 238;
            this.resimKutu22.TabStop = false;
            // 
            // resimKutu23
            // 
            this.resimKutu23.BackColor = System.Drawing.Color.White;
            this.resimKutu23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu23.Location = new System.Drawing.Point(555, 84);
            this.resimKutu23.Name = "resimKutu23";
            this.resimKutu23.Size = new System.Drawing.Size(86, 75);
            this.resimKutu23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu23.TabIndex = 239;
            this.resimKutu23.TabStop = false;
            this.resimKutu23.Click += new System.EventHandler(this.resimKutu23_Click);
            // 
            // resimKutu24
            // 
            this.resimKutu24.BackColor = System.Drawing.Color.White;
            this.resimKutu24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu24.Location = new System.Drawing.Point(647, 84);
            this.resimKutu24.Name = "resimKutu24";
            this.resimKutu24.Size = new System.Drawing.Size(86, 75);
            this.resimKutu24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu24.TabIndex = 240;
            this.resimKutu24.TabStop = false;
            // 
            // resimKutu25
            // 
            this.resimKutu25.BackColor = System.Drawing.Color.White;
            this.resimKutu25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu25.Location = new System.Drawing.Point(739, 84);
            this.resimKutu25.Name = "resimKutu25";
            this.resimKutu25.Size = new System.Drawing.Size(86, 75);
            this.resimKutu25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu25.TabIndex = 241;
            this.resimKutu25.TabStop = false;
            // 
            // resimKutu26
            // 
            this.resimKutu26.BackColor = System.Drawing.Color.White;
            this.resimKutu26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu26.Location = new System.Drawing.Point(831, 84);
            this.resimKutu26.Name = "resimKutu26";
            this.resimKutu26.Size = new System.Drawing.Size(86, 75);
            this.resimKutu26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu26.TabIndex = 242;
            this.resimKutu26.TabStop = false;
            // 
            // resimKutu27
            // 
            this.resimKutu27.BackColor = System.Drawing.Color.White;
            this.resimKutu27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu27.Location = new System.Drawing.Point(923, 84);
            this.resimKutu27.Name = "resimKutu27";
            this.resimKutu27.Size = new System.Drawing.Size(86, 75);
            this.resimKutu27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu27.TabIndex = 243;
            this.resimKutu27.TabStop = false;
            // 
            // resimKutu28
            // 
            this.resimKutu28.BackColor = System.Drawing.Color.White;
            this.resimKutu28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu28.Location = new System.Drawing.Point(1015, 84);
            this.resimKutu28.Name = "resimKutu28";
            this.resimKutu28.Size = new System.Drawing.Size(86, 75);
            this.resimKutu28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu28.TabIndex = 244;
            this.resimKutu28.TabStop = false;
            // 
            // resimKutu29
            // 
            this.resimKutu29.BackColor = System.Drawing.Color.White;
            this.resimKutu29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu29.Location = new System.Drawing.Point(1107, 84);
            this.resimKutu29.Name = "resimKutu29";
            this.resimKutu29.Size = new System.Drawing.Size(86, 75);
            this.resimKutu29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu29.TabIndex = 245;
            this.resimKutu29.TabStop = false;
            // 
            // resimKutu30
            // 
            this.resimKutu30.BackColor = System.Drawing.Color.White;
            this.resimKutu30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu30.Location = new System.Drawing.Point(1199, 84);
            this.resimKutu30.Name = "resimKutu30";
            this.resimKutu30.Size = new System.Drawing.Size(86, 75);
            this.resimKutu30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu30.TabIndex = 246;
            this.resimKutu30.TabStop = false;
            // 
            // resimKutu31
            // 
            this.resimKutu31.BackColor = System.Drawing.Color.White;
            this.resimKutu31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu31.Location = new System.Drawing.Point(1291, 84);
            this.resimKutu31.Name = "resimKutu31";
            this.resimKutu31.Size = new System.Drawing.Size(86, 75);
            this.resimKutu31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu31.TabIndex = 247;
            this.resimKutu31.TabStop = false;
            // 
            // resimKutu32
            // 
            this.resimKutu32.BackColor = System.Drawing.Color.White;
            this.resimKutu32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu32.Location = new System.Drawing.Point(1383, 84);
            this.resimKutu32.Name = "resimKutu32";
            this.resimKutu32.Size = new System.Drawing.Size(92, 75);
            this.resimKutu32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu32.TabIndex = 248;
            this.resimKutu32.TabStop = false;
            // 
            // resimKutu33
            // 
            this.resimKutu33.BackColor = System.Drawing.Color.White;
            this.resimKutu33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu33.Location = new System.Drawing.Point(3, 165);
            this.resimKutu33.Name = "resimKutu33";
            this.resimKutu33.Size = new System.Drawing.Size(86, 75);
            this.resimKutu33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu33.TabIndex = 249;
            this.resimKutu33.TabStop = false;
            // 
            // resimKutu34
            // 
            this.resimKutu34.BackColor = System.Drawing.Color.White;
            this.resimKutu34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu34.Location = new System.Drawing.Point(95, 165);
            this.resimKutu34.Name = "resimKutu34";
            this.resimKutu34.Size = new System.Drawing.Size(86, 75);
            this.resimKutu34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu34.TabIndex = 250;
            this.resimKutu34.TabStop = false;
            // 
            // resimKutu35
            // 
            this.resimKutu35.BackColor = System.Drawing.Color.White;
            this.resimKutu35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu35.Location = new System.Drawing.Point(187, 165);
            this.resimKutu35.Name = "resimKutu35";
            this.resimKutu35.Size = new System.Drawing.Size(86, 75);
            this.resimKutu35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu35.TabIndex = 251;
            this.resimKutu35.TabStop = false;
            // 
            // resimKutu36
            // 
            this.resimKutu36.BackColor = System.Drawing.Color.White;
            this.resimKutu36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu36.Location = new System.Drawing.Point(279, 165);
            this.resimKutu36.Name = "resimKutu36";
            this.resimKutu36.Size = new System.Drawing.Size(86, 75);
            this.resimKutu36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu36.TabIndex = 252;
            this.resimKutu36.TabStop = false;
            // 
            // resimKutu37
            // 
            this.resimKutu37.BackColor = System.Drawing.Color.White;
            this.resimKutu37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu37.Location = new System.Drawing.Point(371, 165);
            this.resimKutu37.Name = "resimKutu37";
            this.resimKutu37.Size = new System.Drawing.Size(86, 75);
            this.resimKutu37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu37.TabIndex = 253;
            this.resimKutu37.TabStop = false;
            // 
            // resimKutu38
            // 
            this.resimKutu38.BackColor = System.Drawing.Color.White;
            this.resimKutu38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu38.Location = new System.Drawing.Point(463, 165);
            this.resimKutu38.Name = "resimKutu38";
            this.resimKutu38.Size = new System.Drawing.Size(86, 75);
            this.resimKutu38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu38.TabIndex = 254;
            this.resimKutu38.TabStop = false;
            // 
            // resimKutu39
            // 
            this.resimKutu39.BackColor = System.Drawing.Color.White;
            this.resimKutu39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu39.Location = new System.Drawing.Point(555, 165);
            this.resimKutu39.Name = "resimKutu39";
            this.resimKutu39.Size = new System.Drawing.Size(86, 75);
            this.resimKutu39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu39.TabIndex = 255;
            this.resimKutu39.TabStop = false;
            // 
            // resimKutu40
            // 
            this.resimKutu40.BackColor = System.Drawing.Color.White;
            this.resimKutu40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu40.Location = new System.Drawing.Point(647, 165);
            this.resimKutu40.Name = "resimKutu40";
            this.resimKutu40.Size = new System.Drawing.Size(86, 75);
            this.resimKutu40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu40.TabIndex = 256;
            this.resimKutu40.TabStop = false;
            // 
            // resimKutu41
            // 
            this.resimKutu41.BackColor = System.Drawing.Color.White;
            this.resimKutu41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu41.Location = new System.Drawing.Point(739, 165);
            this.resimKutu41.Name = "resimKutu41";
            this.resimKutu41.Size = new System.Drawing.Size(86, 75);
            this.resimKutu41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu41.TabIndex = 257;
            this.resimKutu41.TabStop = false;
            // 
            // resimKutu42
            // 
            this.resimKutu42.BackColor = System.Drawing.Color.White;
            this.resimKutu42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu42.Location = new System.Drawing.Point(831, 165);
            this.resimKutu42.Name = "resimKutu42";
            this.resimKutu42.Size = new System.Drawing.Size(86, 75);
            this.resimKutu42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu42.TabIndex = 258;
            this.resimKutu42.TabStop = false;
            // 
            // resimKutu43
            // 
            this.resimKutu43.BackColor = System.Drawing.Color.White;
            this.resimKutu43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu43.Location = new System.Drawing.Point(923, 165);
            this.resimKutu43.Name = "resimKutu43";
            this.resimKutu43.Size = new System.Drawing.Size(86, 75);
            this.resimKutu43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu43.TabIndex = 259;
            this.resimKutu43.TabStop = false;
            // 
            // resimKutu44
            // 
            this.resimKutu44.BackColor = System.Drawing.Color.White;
            this.resimKutu44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu44.Location = new System.Drawing.Point(1015, 165);
            this.resimKutu44.Name = "resimKutu44";
            this.resimKutu44.Size = new System.Drawing.Size(86, 75);
            this.resimKutu44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu44.TabIndex = 260;
            this.resimKutu44.TabStop = false;
            // 
            // resimKutu45
            // 
            this.resimKutu45.BackColor = System.Drawing.Color.White;
            this.resimKutu45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu45.Location = new System.Drawing.Point(1107, 165);
            this.resimKutu45.Name = "resimKutu45";
            this.resimKutu45.Size = new System.Drawing.Size(86, 75);
            this.resimKutu45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu45.TabIndex = 261;
            this.resimKutu45.TabStop = false;
            // 
            // resimKutu46
            // 
            this.resimKutu46.BackColor = System.Drawing.Color.White;
            this.resimKutu46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu46.Location = new System.Drawing.Point(1199, 165);
            this.resimKutu46.Name = "resimKutu46";
            this.resimKutu46.Size = new System.Drawing.Size(86, 75);
            this.resimKutu46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu46.TabIndex = 262;
            this.resimKutu46.TabStop = false;
            // 
            // resimKutu47
            // 
            this.resimKutu47.BackColor = System.Drawing.Color.White;
            this.resimKutu47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu47.Location = new System.Drawing.Point(1291, 165);
            this.resimKutu47.Name = "resimKutu47";
            this.resimKutu47.Size = new System.Drawing.Size(86, 75);
            this.resimKutu47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu47.TabIndex = 263;
            this.resimKutu47.TabStop = false;
            // 
            // resimKutu48
            // 
            this.resimKutu48.BackColor = System.Drawing.Color.White;
            this.resimKutu48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu48.Location = new System.Drawing.Point(1383, 165);
            this.resimKutu48.Name = "resimKutu48";
            this.resimKutu48.Size = new System.Drawing.Size(92, 75);
            this.resimKutu48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu48.TabIndex = 264;
            this.resimKutu48.TabStop = false;
            // 
            // resimKutu49
            // 
            this.resimKutu49.BackColor = System.Drawing.Color.White;
            this.resimKutu49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu49.Location = new System.Drawing.Point(3, 246);
            this.resimKutu49.Name = "resimKutu49";
            this.resimKutu49.Size = new System.Drawing.Size(86, 75);
            this.resimKutu49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu49.TabIndex = 265;
            this.resimKutu49.TabStop = false;
            // 
            // resimKutu50
            // 
            this.resimKutu50.BackColor = System.Drawing.Color.White;
            this.resimKutu50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu50.Location = new System.Drawing.Point(95, 246);
            this.resimKutu50.Name = "resimKutu50";
            this.resimKutu50.Size = new System.Drawing.Size(86, 75);
            this.resimKutu50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu50.TabIndex = 266;
            this.resimKutu50.TabStop = false;
            // 
            // resimKutu51
            // 
            this.resimKutu51.BackColor = System.Drawing.Color.White;
            this.resimKutu51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu51.Location = new System.Drawing.Point(187, 246);
            this.resimKutu51.Name = "resimKutu51";
            this.resimKutu51.Size = new System.Drawing.Size(86, 75);
            this.resimKutu51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu51.TabIndex = 267;
            this.resimKutu51.TabStop = false;
            // 
            // resimKutu52
            // 
            this.resimKutu52.BackColor = System.Drawing.Color.White;
            this.resimKutu52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu52.Location = new System.Drawing.Point(279, 246);
            this.resimKutu52.Name = "resimKutu52";
            this.resimKutu52.Size = new System.Drawing.Size(86, 75);
            this.resimKutu52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu52.TabIndex = 268;
            this.resimKutu52.TabStop = false;
            // 
            // resimKutu53
            // 
            this.resimKutu53.BackColor = System.Drawing.Color.White;
            this.resimKutu53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu53.Location = new System.Drawing.Point(371, 246);
            this.resimKutu53.Name = "resimKutu53";
            this.resimKutu53.Size = new System.Drawing.Size(86, 75);
            this.resimKutu53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu53.TabIndex = 269;
            this.resimKutu53.TabStop = false;
            // 
            // resimKutu54
            // 
            this.resimKutu54.BackColor = System.Drawing.Color.White;
            this.resimKutu54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu54.Location = new System.Drawing.Point(463, 246);
            this.resimKutu54.Name = "resimKutu54";
            this.resimKutu54.Size = new System.Drawing.Size(86, 75);
            this.resimKutu54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu54.TabIndex = 270;
            this.resimKutu54.TabStop = false;
            // 
            // resimKutu55
            // 
            this.resimKutu55.BackColor = System.Drawing.Color.White;
            this.resimKutu55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu55.Location = new System.Drawing.Point(555, 246);
            this.resimKutu55.Name = "resimKutu55";
            this.resimKutu55.Size = new System.Drawing.Size(86, 75);
            this.resimKutu55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu55.TabIndex = 271;
            this.resimKutu55.TabStop = false;
            // 
            // resimKutu56
            // 
            this.resimKutu56.BackColor = System.Drawing.Color.White;
            this.resimKutu56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu56.Location = new System.Drawing.Point(647, 246);
            this.resimKutu56.Name = "resimKutu56";
            this.resimKutu56.Size = new System.Drawing.Size(86, 75);
            this.resimKutu56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu56.TabIndex = 272;
            this.resimKutu56.TabStop = false;
            // 
            // resimKutu57
            // 
            this.resimKutu57.BackColor = System.Drawing.Color.White;
            this.resimKutu57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu57.Location = new System.Drawing.Point(739, 246);
            this.resimKutu57.Name = "resimKutu57";
            this.resimKutu57.Size = new System.Drawing.Size(86, 75);
            this.resimKutu57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu57.TabIndex = 273;
            this.resimKutu57.TabStop = false;
            // 
            // resimKutu58
            // 
            this.resimKutu58.BackColor = System.Drawing.Color.White;
            this.resimKutu58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu58.Location = new System.Drawing.Point(831, 246);
            this.resimKutu58.Name = "resimKutu58";
            this.resimKutu58.Size = new System.Drawing.Size(86, 75);
            this.resimKutu58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu58.TabIndex = 279;
            this.resimKutu58.TabStop = false;
            // 
            // resimKutu59
            // 
            this.resimKutu59.BackColor = System.Drawing.Color.White;
            this.resimKutu59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu59.Location = new System.Drawing.Point(923, 246);
            this.resimKutu59.Name = "resimKutu59";
            this.resimKutu59.Size = new System.Drawing.Size(86, 75);
            this.resimKutu59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu59.TabIndex = 278;
            this.resimKutu59.TabStop = false;
            // 
            // resimKutu60
            // 
            this.resimKutu60.BackColor = System.Drawing.Color.White;
            this.resimKutu60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu60.Location = new System.Drawing.Point(1015, 246);
            this.resimKutu60.Name = "resimKutu60";
            this.resimKutu60.Size = new System.Drawing.Size(86, 75);
            this.resimKutu60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu60.TabIndex = 277;
            this.resimKutu60.TabStop = false;
            // 
            // resimKutu61
            // 
            this.resimKutu61.BackColor = System.Drawing.Color.White;
            this.resimKutu61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu61.Location = new System.Drawing.Point(1107, 246);
            this.resimKutu61.Name = "resimKutu61";
            this.resimKutu61.Size = new System.Drawing.Size(86, 75);
            this.resimKutu61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu61.TabIndex = 280;
            this.resimKutu61.TabStop = false;
            // 
            // resimKutu62
            // 
            this.resimKutu62.BackColor = System.Drawing.Color.White;
            this.resimKutu62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu62.Location = new System.Drawing.Point(1199, 246);
            this.resimKutu62.Name = "resimKutu62";
            this.resimKutu62.Size = new System.Drawing.Size(86, 75);
            this.resimKutu62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu62.TabIndex = 276;
            this.resimKutu62.TabStop = false;
            // 
            // resimKutu63
            // 
            this.resimKutu63.BackColor = System.Drawing.Color.White;
            this.resimKutu63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu63.Location = new System.Drawing.Point(1291, 246);
            this.resimKutu63.Name = "resimKutu63";
            this.resimKutu63.Size = new System.Drawing.Size(86, 75);
            this.resimKutu63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu63.TabIndex = 281;
            this.resimKutu63.TabStop = false;
            // 
            // resimKutu64
            // 
            this.resimKutu64.BackColor = System.Drawing.Color.White;
            this.resimKutu64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu64.Location = new System.Drawing.Point(1383, 246);
            this.resimKutu64.Name = "resimKutu64";
            this.resimKutu64.Size = new System.Drawing.Size(92, 75);
            this.resimKutu64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu64.TabIndex = 275;
            this.resimKutu64.TabStop = false;
            // 
            // resimKutu65
            // 
            this.resimKutu65.BackColor = System.Drawing.Color.White;
            this.resimKutu65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu65.Location = new System.Drawing.Point(3, 327);
            this.resimKutu65.Name = "resimKutu65";
            this.resimKutu65.Size = new System.Drawing.Size(86, 75);
            this.resimKutu65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu65.TabIndex = 274;
            this.resimKutu65.TabStop = false;
            // 
            // resimKutu66
            // 
            this.resimKutu66.BackColor = System.Drawing.Color.White;
            this.resimKutu66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu66.Location = new System.Drawing.Point(95, 327);
            this.resimKutu66.Name = "resimKutu66";
            this.resimKutu66.Size = new System.Drawing.Size(86, 75);
            this.resimKutu66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu66.TabIndex = 292;
            this.resimKutu66.TabStop = false;
            // 
            // resimKutu67
            // 
            this.resimKutu67.BackColor = System.Drawing.Color.White;
            this.resimKutu67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu67.Location = new System.Drawing.Point(187, 327);
            this.resimKutu67.Name = "resimKutu67";
            this.resimKutu67.Size = new System.Drawing.Size(86, 75);
            this.resimKutu67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu67.TabIndex = 293;
            this.resimKutu67.TabStop = false;
            // 
            // resimKutu68
            // 
            this.resimKutu68.BackColor = System.Drawing.Color.White;
            this.resimKutu68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu68.Location = new System.Drawing.Point(279, 327);
            this.resimKutu68.Name = "resimKutu68";
            this.resimKutu68.Size = new System.Drawing.Size(86, 75);
            this.resimKutu68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu68.TabIndex = 291;
            this.resimKutu68.TabStop = false;
            // 
            // resimKutu69
            // 
            this.resimKutu69.BackColor = System.Drawing.Color.White;
            this.resimKutu69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu69.Location = new System.Drawing.Point(371, 327);
            this.resimKutu69.Name = "resimKutu69";
            this.resimKutu69.Size = new System.Drawing.Size(86, 75);
            this.resimKutu69.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu69.TabIndex = 294;
            this.resimKutu69.TabStop = false;
            // 
            // resimKutu70
            // 
            this.resimKutu70.BackColor = System.Drawing.Color.White;
            this.resimKutu70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu70.Location = new System.Drawing.Point(463, 327);
            this.resimKutu70.Name = "resimKutu70";
            this.resimKutu70.Size = new System.Drawing.Size(86, 75);
            this.resimKutu70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu70.TabIndex = 290;
            this.resimKutu70.TabStop = false;
            // 
            // resimKutu71
            // 
            this.resimKutu71.BackColor = System.Drawing.Color.White;
            this.resimKutu71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu71.Location = new System.Drawing.Point(555, 327);
            this.resimKutu71.Name = "resimKutu71";
            this.resimKutu71.Size = new System.Drawing.Size(86, 75);
            this.resimKutu71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu71.TabIndex = 289;
            this.resimKutu71.TabStop = false;
            // 
            // resimKutu72
            // 
            this.resimKutu72.BackColor = System.Drawing.Color.White;
            this.resimKutu72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu72.Location = new System.Drawing.Point(647, 327);
            this.resimKutu72.Name = "resimKutu72";
            this.resimKutu72.Size = new System.Drawing.Size(86, 75);
            this.resimKutu72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu72.TabIndex = 288;
            this.resimKutu72.TabStop = false;
            // 
            // resimKutu73
            // 
            this.resimKutu73.BackColor = System.Drawing.Color.White;
            this.resimKutu73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu73.Location = new System.Drawing.Point(739, 327);
            this.resimKutu73.Name = "resimKutu73";
            this.resimKutu73.Size = new System.Drawing.Size(86, 75);
            this.resimKutu73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu73.TabIndex = 295;
            this.resimKutu73.TabStop = false;
            // 
            // resimKutu74
            // 
            this.resimKutu74.BackColor = System.Drawing.Color.White;
            this.resimKutu74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu74.Location = new System.Drawing.Point(831, 327);
            this.resimKutu74.Name = "resimKutu74";
            this.resimKutu74.Size = new System.Drawing.Size(86, 75);
            this.resimKutu74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu74.TabIndex = 287;
            this.resimKutu74.TabStop = false;
            // 
            // resimKutu75
            // 
            this.resimKutu75.BackColor = System.Drawing.Color.White;
            this.resimKutu75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu75.Location = new System.Drawing.Point(923, 327);
            this.resimKutu75.Name = "resimKutu75";
            this.resimKutu75.Size = new System.Drawing.Size(86, 75);
            this.resimKutu75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu75.TabIndex = 286;
            this.resimKutu75.TabStop = false;
            // 
            // resimKutu76
            // 
            this.resimKutu76.BackColor = System.Drawing.Color.White;
            this.resimKutu76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu76.Location = new System.Drawing.Point(1015, 327);
            this.resimKutu76.Name = "resimKutu76";
            this.resimKutu76.Size = new System.Drawing.Size(86, 75);
            this.resimKutu76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu76.TabIndex = 285;
            this.resimKutu76.TabStop = false;
            // 
            // resimKutu77
            // 
            this.resimKutu77.BackColor = System.Drawing.Color.White;
            this.resimKutu77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu77.Location = new System.Drawing.Point(1107, 327);
            this.resimKutu77.Name = "resimKutu77";
            this.resimKutu77.Size = new System.Drawing.Size(86, 75);
            this.resimKutu77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu77.TabIndex = 296;
            this.resimKutu77.TabStop = false;
            // 
            // resimKutu78
            // 
            this.resimKutu78.BackColor = System.Drawing.Color.White;
            this.resimKutu78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu78.Location = new System.Drawing.Point(1199, 327);
            this.resimKutu78.Name = "resimKutu78";
            this.resimKutu78.Size = new System.Drawing.Size(86, 75);
            this.resimKutu78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu78.TabIndex = 284;
            this.resimKutu78.TabStop = false;
            // 
            // resimKutu79
            // 
            this.resimKutu79.BackColor = System.Drawing.Color.White;
            this.resimKutu79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu79.Location = new System.Drawing.Point(1291, 327);
            this.resimKutu79.Name = "resimKutu79";
            this.resimKutu79.Size = new System.Drawing.Size(86, 75);
            this.resimKutu79.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu79.TabIndex = 297;
            this.resimKutu79.TabStop = false;
            // 
            // resimKutu80
            // 
            this.resimKutu80.BackColor = System.Drawing.Color.White;
            this.resimKutu80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu80.Location = new System.Drawing.Point(1383, 327);
            this.resimKutu80.Name = "resimKutu80";
            this.resimKutu80.Size = new System.Drawing.Size(92, 75);
            this.resimKutu80.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu80.TabIndex = 283;
            this.resimKutu80.TabStop = false;
            // 
            // resimKutu81
            // 
            this.resimKutu81.BackColor = System.Drawing.Color.White;
            this.resimKutu81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu81.Location = new System.Drawing.Point(3, 408);
            this.resimKutu81.Name = "resimKutu81";
            this.resimKutu81.Size = new System.Drawing.Size(86, 75);
            this.resimKutu81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu81.TabIndex = 282;
            this.resimKutu81.TabStop = false;
            // 
            // resimKutu82
            // 
            this.resimKutu82.BackColor = System.Drawing.Color.White;
            this.resimKutu82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu82.Location = new System.Drawing.Point(95, 408);
            this.resimKutu82.Name = "resimKutu82";
            this.resimKutu82.Size = new System.Drawing.Size(86, 75);
            this.resimKutu82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu82.TabIndex = 308;
            this.resimKutu82.TabStop = false;
            // 
            // resimKutu83
            // 
            this.resimKutu83.BackColor = System.Drawing.Color.White;
            this.resimKutu83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu83.Location = new System.Drawing.Point(187, 408);
            this.resimKutu83.Name = "resimKutu83";
            this.resimKutu83.Size = new System.Drawing.Size(86, 75);
            this.resimKutu83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu83.TabIndex = 307;
            this.resimKutu83.TabStop = false;
            // 
            // resimKutu84
            // 
            this.resimKutu84.BackColor = System.Drawing.Color.White;
            this.resimKutu84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu84.Location = new System.Drawing.Point(279, 408);
            this.resimKutu84.Name = "resimKutu84";
            this.resimKutu84.Size = new System.Drawing.Size(86, 75);
            this.resimKutu84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu84.TabIndex = 309;
            this.resimKutu84.TabStop = false;
            // 
            // resimKutu85
            // 
            this.resimKutu85.BackColor = System.Drawing.Color.White;
            this.resimKutu85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu85.Location = new System.Drawing.Point(371, 408);
            this.resimKutu85.Name = "resimKutu85";
            this.resimKutu85.Size = new System.Drawing.Size(86, 75);
            this.resimKutu85.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu85.TabIndex = 306;
            this.resimKutu85.TabStop = false;
            // 
            // resimKutu86
            // 
            this.resimKutu86.BackColor = System.Drawing.Color.White;
            this.resimKutu86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu86.Location = new System.Drawing.Point(463, 408);
            this.resimKutu86.Name = "resimKutu86";
            this.resimKutu86.Size = new System.Drawing.Size(86, 75);
            this.resimKutu86.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu86.TabIndex = 305;
            this.resimKutu86.TabStop = false;
            // 
            // resimKutu87
            // 
            this.resimKutu87.BackColor = System.Drawing.Color.White;
            this.resimKutu87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu87.Location = new System.Drawing.Point(555, 408);
            this.resimKutu87.Name = "resimKutu87";
            this.resimKutu87.Size = new System.Drawing.Size(86, 75);
            this.resimKutu87.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu87.TabIndex = 304;
            this.resimKutu87.TabStop = false;
            // 
            // resimKutu88
            // 
            this.resimKutu88.BackColor = System.Drawing.Color.White;
            this.resimKutu88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu88.Location = new System.Drawing.Point(647, 408);
            this.resimKutu88.Name = "resimKutu88";
            this.resimKutu88.Size = new System.Drawing.Size(86, 75);
            this.resimKutu88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu88.TabIndex = 310;
            this.resimKutu88.TabStop = false;
            // 
            // resimKutu89
            // 
            this.resimKutu89.BackColor = System.Drawing.Color.White;
            this.resimKutu89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu89.Location = new System.Drawing.Point(739, 408);
            this.resimKutu89.Name = "resimKutu89";
            this.resimKutu89.Size = new System.Drawing.Size(86, 75);
            this.resimKutu89.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu89.TabIndex = 303;
            this.resimKutu89.TabStop = false;
            // 
            // resimKutu90
            // 
            this.resimKutu90.BackColor = System.Drawing.Color.White;
            this.resimKutu90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu90.Location = new System.Drawing.Point(831, 408);
            this.resimKutu90.Name = "resimKutu90";
            this.resimKutu90.Size = new System.Drawing.Size(86, 75);
            this.resimKutu90.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu90.TabIndex = 302;
            this.resimKutu90.TabStop = false;
            // 
            // resimKutu91
            // 
            this.resimKutu91.BackColor = System.Drawing.Color.White;
            this.resimKutu91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu91.Location = new System.Drawing.Point(923, 408);
            this.resimKutu91.Name = "resimKutu91";
            this.resimKutu91.Size = new System.Drawing.Size(86, 75);
            this.resimKutu91.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu91.TabIndex = 301;
            this.resimKutu91.TabStop = false;
            // 
            // resimKutu92
            // 
            this.resimKutu92.BackColor = System.Drawing.Color.White;
            this.resimKutu92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu92.Location = new System.Drawing.Point(1015, 408);
            this.resimKutu92.Name = "resimKutu92";
            this.resimKutu92.Size = new System.Drawing.Size(86, 75);
            this.resimKutu92.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu92.TabIndex = 311;
            this.resimKutu92.TabStop = false;
            // 
            // resimKutu93
            // 
            this.resimKutu93.BackColor = System.Drawing.Color.White;
            this.resimKutu93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu93.Location = new System.Drawing.Point(1107, 408);
            this.resimKutu93.Name = "resimKutu93";
            this.resimKutu93.Size = new System.Drawing.Size(86, 75);
            this.resimKutu93.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu93.TabIndex = 300;
            this.resimKutu93.TabStop = false;
            // 
            // resimKutu94
            // 
            this.resimKutu94.BackColor = System.Drawing.Color.White;
            this.resimKutu94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu94.Location = new System.Drawing.Point(1199, 408);
            this.resimKutu94.Name = "resimKutu94";
            this.resimKutu94.Size = new System.Drawing.Size(86, 75);
            this.resimKutu94.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu94.TabIndex = 312;
            this.resimKutu94.TabStop = false;
            // 
            // resimKutu95
            // 
            this.resimKutu95.BackColor = System.Drawing.Color.White;
            this.resimKutu95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu95.Location = new System.Drawing.Point(1291, 408);
            this.resimKutu95.Name = "resimKutu95";
            this.resimKutu95.Size = new System.Drawing.Size(86, 75);
            this.resimKutu95.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu95.TabIndex = 299;
            this.resimKutu95.TabStop = false;
            // 
            // resimKutu96
            // 
            this.resimKutu96.BackColor = System.Drawing.Color.White;
            this.resimKutu96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu96.Location = new System.Drawing.Point(1383, 408);
            this.resimKutu96.Name = "resimKutu96";
            this.resimKutu96.Size = new System.Drawing.Size(92, 75);
            this.resimKutu96.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu96.TabIndex = 298;
            this.resimKutu96.TabStop = false;
            // 
            // resimKutu97
            // 
            this.resimKutu97.BackColor = System.Drawing.Color.White;
            this.resimKutu97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu97.Location = new System.Drawing.Point(3, 489);
            this.resimKutu97.Name = "resimKutu97";
            this.resimKutu97.Size = new System.Drawing.Size(86, 75);
            this.resimKutu97.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu97.TabIndex = 323;
            this.resimKutu97.TabStop = false;
            // 
            // resimKutu98
            // 
            this.resimKutu98.BackColor = System.Drawing.Color.White;
            this.resimKutu98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu98.Location = new System.Drawing.Point(95, 489);
            this.resimKutu98.Name = "resimKutu98";
            this.resimKutu98.Size = new System.Drawing.Size(86, 75);
            this.resimKutu98.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu98.TabIndex = 324;
            this.resimKutu98.TabStop = false;
            // 
            // resimKutu99
            // 
            this.resimKutu99.BackColor = System.Drawing.Color.White;
            this.resimKutu99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu99.Location = new System.Drawing.Point(187, 489);
            this.resimKutu99.Name = "resimKutu99";
            this.resimKutu99.Size = new System.Drawing.Size(86, 75);
            this.resimKutu99.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu99.TabIndex = 322;
            this.resimKutu99.TabStop = false;
            // 
            // resimKutu100
            // 
            this.resimKutu100.BackColor = System.Drawing.Color.White;
            this.resimKutu100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu100.Location = new System.Drawing.Point(279, 489);
            this.resimKutu100.Name = "resimKutu100";
            this.resimKutu100.Size = new System.Drawing.Size(86, 75);
            this.resimKutu100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu100.TabIndex = 325;
            this.resimKutu100.TabStop = false;
            // 
            // resimKutu101
            // 
            this.resimKutu101.BackColor = System.Drawing.Color.White;
            this.resimKutu101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu101.Location = new System.Drawing.Point(371, 489);
            this.resimKutu101.Name = "resimKutu101";
            this.resimKutu101.Size = new System.Drawing.Size(86, 75);
            this.resimKutu101.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu101.TabIndex = 321;
            this.resimKutu101.TabStop = false;
            // 
            // resimKutu102
            // 
            this.resimKutu102.BackColor = System.Drawing.Color.White;
            this.resimKutu102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu102.Location = new System.Drawing.Point(463, 489);
            this.resimKutu102.Name = "resimKutu102";
            this.resimKutu102.Size = new System.Drawing.Size(86, 75);
            this.resimKutu102.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu102.TabIndex = 320;
            this.resimKutu102.TabStop = false;
            // 
            // resimKutu103
            // 
            this.resimKutu103.BackColor = System.Drawing.Color.White;
            this.resimKutu103.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu103.Location = new System.Drawing.Point(555, 489);
            this.resimKutu103.Name = "resimKutu103";
            this.resimKutu103.Size = new System.Drawing.Size(86, 75);
            this.resimKutu103.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu103.TabIndex = 319;
            this.resimKutu103.TabStop = false;
            // 
            // resimKutu104
            // 
            this.resimKutu104.BackColor = System.Drawing.Color.White;
            this.resimKutu104.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu104.Location = new System.Drawing.Point(647, 489);
            this.resimKutu104.Name = "resimKutu104";
            this.resimKutu104.Size = new System.Drawing.Size(86, 75);
            this.resimKutu104.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu104.TabIndex = 326;
            this.resimKutu104.TabStop = false;
            // 
            // resimKutu105
            // 
            this.resimKutu105.BackColor = System.Drawing.Color.White;
            this.resimKutu105.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu105.Location = new System.Drawing.Point(739, 489);
            this.resimKutu105.Name = "resimKutu105";
            this.resimKutu105.Size = new System.Drawing.Size(86, 75);
            this.resimKutu105.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu105.TabIndex = 318;
            this.resimKutu105.TabStop = false;
            // 
            // resimKutu106
            // 
            this.resimKutu106.BackColor = System.Drawing.Color.White;
            this.resimKutu106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu106.Location = new System.Drawing.Point(831, 489);
            this.resimKutu106.Name = "resimKutu106";
            this.resimKutu106.Size = new System.Drawing.Size(86, 75);
            this.resimKutu106.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu106.TabIndex = 317;
            this.resimKutu106.TabStop = false;
            // 
            // resimKutu107
            // 
            this.resimKutu107.BackColor = System.Drawing.Color.White;
            this.resimKutu107.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu107.Location = new System.Drawing.Point(923, 489);
            this.resimKutu107.Name = "resimKutu107";
            this.resimKutu107.Size = new System.Drawing.Size(86, 75);
            this.resimKutu107.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu107.TabIndex = 316;
            this.resimKutu107.TabStop = false;
            // 
            // resimKutu108
            // 
            this.resimKutu108.BackColor = System.Drawing.Color.White;
            this.resimKutu108.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu108.Location = new System.Drawing.Point(1015, 489);
            this.resimKutu108.Name = "resimKutu108";
            this.resimKutu108.Size = new System.Drawing.Size(86, 75);
            this.resimKutu108.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu108.TabIndex = 327;
            this.resimKutu108.TabStop = false;
            // 
            // resimKutu109
            // 
            this.resimKutu109.BackColor = System.Drawing.Color.White;
            this.resimKutu109.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu109.Location = new System.Drawing.Point(1107, 489);
            this.resimKutu109.Name = "resimKutu109";
            this.resimKutu109.Size = new System.Drawing.Size(86, 75);
            this.resimKutu109.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu109.TabIndex = 315;
            this.resimKutu109.TabStop = false;
            // 
            // resimKutu110
            // 
            this.resimKutu110.BackColor = System.Drawing.Color.White;
            this.resimKutu110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu110.Location = new System.Drawing.Point(1199, 489);
            this.resimKutu110.Name = "resimKutu110";
            this.resimKutu110.Size = new System.Drawing.Size(86, 75);
            this.resimKutu110.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu110.TabIndex = 328;
            this.resimKutu110.TabStop = false;
            // 
            // resimKutu111
            // 
            this.resimKutu111.BackColor = System.Drawing.Color.White;
            this.resimKutu111.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu111.Location = new System.Drawing.Point(1291, 489);
            this.resimKutu111.Name = "resimKutu111";
            this.resimKutu111.Size = new System.Drawing.Size(86, 75);
            this.resimKutu111.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu111.TabIndex = 314;
            this.resimKutu111.TabStop = false;
            // 
            // resimKutu112
            // 
            this.resimKutu112.BackColor = System.Drawing.Color.White;
            this.resimKutu112.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu112.Location = new System.Drawing.Point(1383, 489);
            this.resimKutu112.Name = "resimKutu112";
            this.resimKutu112.Size = new System.Drawing.Size(92, 75);
            this.resimKutu112.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu112.TabIndex = 313;
            this.resimKutu112.TabStop = false;
            // 
            // resimKutu113
            // 
            this.resimKutu113.BackColor = System.Drawing.Color.White;
            this.resimKutu113.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu113.Location = new System.Drawing.Point(3, 570);
            this.resimKutu113.Name = "resimKutu113";
            this.resimKutu113.Size = new System.Drawing.Size(86, 75);
            this.resimKutu113.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu113.TabIndex = 339;
            this.resimKutu113.TabStop = false;
            this.resimKutu113.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // resimKutu114
            // 
            this.resimKutu114.BackColor = System.Drawing.Color.White;
            this.resimKutu114.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu114.Location = new System.Drawing.Point(95, 570);
            this.resimKutu114.Name = "resimKutu114";
            this.resimKutu114.Size = new System.Drawing.Size(86, 75);
            this.resimKutu114.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu114.TabIndex = 337;
            this.resimKutu114.TabStop = false;
            // 
            // resimKutu115
            // 
            this.resimKutu115.BackColor = System.Drawing.Color.White;
            this.resimKutu115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu115.Location = new System.Drawing.Point(187, 570);
            this.resimKutu115.Name = "resimKutu115";
            this.resimKutu115.Size = new System.Drawing.Size(86, 75);
            this.resimKutu115.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu115.TabIndex = 341;
            this.resimKutu115.TabStop = false;
            // 
            // resimKutu116
            // 
            this.resimKutu116.BackColor = System.Drawing.Color.White;
            this.resimKutu116.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu116.Location = new System.Drawing.Point(279, 570);
            this.resimKutu116.Name = "resimKutu116";
            this.resimKutu116.Size = new System.Drawing.Size(86, 75);
            this.resimKutu116.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu116.TabIndex = 340;
            this.resimKutu116.TabStop = false;
            // 
            // resimKutu117
            // 
            this.resimKutu117.BackColor = System.Drawing.Color.White;
            this.resimKutu117.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu117.Location = new System.Drawing.Point(371, 570);
            this.resimKutu117.Name = "resimKutu117";
            this.resimKutu117.Size = new System.Drawing.Size(86, 75);
            this.resimKutu117.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu117.TabIndex = 336;
            this.resimKutu117.TabStop = false;
            // 
            // resimKutu118
            // 
            this.resimKutu118.BackColor = System.Drawing.Color.White;
            this.resimKutu118.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu118.Location = new System.Drawing.Point(463, 570);
            this.resimKutu118.Name = "resimKutu118";
            this.resimKutu118.Size = new System.Drawing.Size(86, 75);
            this.resimKutu118.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu118.TabIndex = 335;
            this.resimKutu118.TabStop = false;
            // 
            // resimKutu119
            // 
            this.resimKutu119.BackColor = System.Drawing.Color.White;
            this.resimKutu119.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu119.Location = new System.Drawing.Point(555, 570);
            this.resimKutu119.Name = "resimKutu119";
            this.resimKutu119.Size = new System.Drawing.Size(86, 75);
            this.resimKutu119.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu119.TabIndex = 334;
            this.resimKutu119.TabStop = false;
            // 
            // resimKutu120
            // 
            this.resimKutu120.BackColor = System.Drawing.Color.White;
            this.resimKutu120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu120.Location = new System.Drawing.Point(647, 570);
            this.resimKutu120.Name = "resimKutu120";
            this.resimKutu120.Size = new System.Drawing.Size(86, 75);
            this.resimKutu120.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu120.TabIndex = 342;
            this.resimKutu120.TabStop = false;
            // 
            // resimKutu121
            // 
            this.resimKutu121.BackColor = System.Drawing.Color.White;
            this.resimKutu121.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu121.Location = new System.Drawing.Point(739, 570);
            this.resimKutu121.Name = "resimKutu121";
            this.resimKutu121.Size = new System.Drawing.Size(86, 75);
            this.resimKutu121.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu121.TabIndex = 333;
            this.resimKutu121.TabStop = false;
            // 
            // resimKutu122
            // 
            this.resimKutu122.BackColor = System.Drawing.Color.White;
            this.resimKutu122.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu122.Location = new System.Drawing.Point(831, 570);
            this.resimKutu122.Name = "resimKutu122";
            this.resimKutu122.Size = new System.Drawing.Size(86, 75);
            this.resimKutu122.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu122.TabIndex = 331;
            this.resimKutu122.TabStop = false;
            // 
            // resimKutu123
            // 
            this.resimKutu123.BackColor = System.Drawing.Color.White;
            this.resimKutu123.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu123.Location = new System.Drawing.Point(923, 570);
            this.resimKutu123.Name = "resimKutu123";
            this.resimKutu123.Size = new System.Drawing.Size(86, 75);
            this.resimKutu123.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu123.TabIndex = 332;
            this.resimKutu123.TabStop = false;
            // 
            // resimKutu124
            // 
            this.resimKutu124.BackColor = System.Drawing.Color.White;
            this.resimKutu124.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu124.Location = new System.Drawing.Point(1015, 570);
            this.resimKutu124.Name = "resimKutu124";
            this.resimKutu124.Size = new System.Drawing.Size(86, 75);
            this.resimKutu124.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu124.TabIndex = 330;
            this.resimKutu124.TabStop = false;
            // 
            // resimKutu125
            // 
            this.resimKutu125.BackColor = System.Drawing.Color.White;
            this.resimKutu125.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu125.Location = new System.Drawing.Point(1107, 570);
            this.resimKutu125.Name = "resimKutu125";
            this.resimKutu125.Size = new System.Drawing.Size(86, 75);
            this.resimKutu125.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu125.TabIndex = 343;
            this.resimKutu125.TabStop = false;
            // 
            // resimKutu126
            // 
            this.resimKutu126.BackColor = System.Drawing.Color.White;
            this.resimKutu126.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu126.Location = new System.Drawing.Point(1199, 570);
            this.resimKutu126.Name = "resimKutu126";
            this.resimKutu126.Size = new System.Drawing.Size(86, 75);
            this.resimKutu126.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu126.TabIndex = 329;
            this.resimKutu126.TabStop = false;
            // 
            // resimKutu127
            // 
            this.resimKutu127.BackColor = System.Drawing.Color.White;
            this.resimKutu127.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu127.Location = new System.Drawing.Point(1291, 570);
            this.resimKutu127.Name = "resimKutu127";
            this.resimKutu127.Size = new System.Drawing.Size(86, 75);
            this.resimKutu127.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu127.TabIndex = 344;
            this.resimKutu127.TabStop = false;
            // 
            // resimKutu128
            // 
            this.resimKutu128.BackColor = System.Drawing.Color.White;
            this.resimKutu128.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resimKutu128.Location = new System.Drawing.Point(1383, 570);
            this.resimKutu128.Name = "resimKutu128";
            this.resimKutu128.Size = new System.Drawing.Size(92, 75);
            this.resimKutu128.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resimKutu128.TabIndex = 338;
            this.resimKutu128.TabStop = false;
            // 
            // anaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(40)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(1478, 762);
            this.Controls.Add(this.cerceveAna);
            this.Controls.Add(this.Menu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.Menu;
            this.Name = "anaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resim Yerleştirme ";
            this.Load += new System.EventHandler(this.anaForm_Load);
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.cerceveAna.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu136)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu130)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu141)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu140)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutu128)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem dosyaIslemleri;
        private System.Windows.Forms.ToolStripMenuItem dosyaAc;
        private System.Windows.Forms.ImageList resimListe;
        private System.Windows.Forms.ToolStripMenuItem kapatTemizleToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel cerceveAna;
        private System.Windows.Forms.PictureBox resimKutu54;
        private System.Windows.Forms.PictureBox resimKutu1;
        private System.Windows.Forms.PictureBox resimKutu53;
        private System.Windows.Forms.PictureBox resimKutu2;
        private System.Windows.Forms.PictureBox resimKutu52;
        private System.Windows.Forms.PictureBox resimKutu3;
        private System.Windows.Forms.PictureBox resimKutu51;
        private System.Windows.Forms.PictureBox resimKutu4;
        private System.Windows.Forms.PictureBox resimKutu50;
        private System.Windows.Forms.PictureBox resimKutu5;
        private System.Windows.Forms.PictureBox resimKutu6;
        private System.Windows.Forms.PictureBox resimKutu48;
        private System.Windows.Forms.PictureBox resimKutu7;
        private System.Windows.Forms.PictureBox resimKutu8;
        private System.Windows.Forms.PictureBox resimKutu46;
        private System.Windows.Forms.PictureBox resimKutu9;
        private System.Windows.Forms.PictureBox resimKutu45;
        private System.Windows.Forms.PictureBox resimKutu10;
        private System.Windows.Forms.PictureBox resimKutu44;
        private System.Windows.Forms.PictureBox resimKutu11;
        private System.Windows.Forms.PictureBox resimKutu43;
        private System.Windows.Forms.PictureBox resimKutu12;
        private System.Windows.Forms.PictureBox resimKutu42;
        private System.Windows.Forms.PictureBox resimKutu13;
        private System.Windows.Forms.PictureBox resimKutu14;
        private System.Windows.Forms.PictureBox resimKutu40;
        private System.Windows.Forms.PictureBox resimKutu15;
        private System.Windows.Forms.PictureBox resimKutu16;
        private System.Windows.Forms.PictureBox resimKutu38;
        private System.Windows.Forms.PictureBox resimKutu17;
        private System.Windows.Forms.PictureBox resimKutu37;
        private System.Windows.Forms.PictureBox resimKutu18;
        private System.Windows.Forms.PictureBox resimKutu36;
        private System.Windows.Forms.PictureBox resimKutu19;
        private System.Windows.Forms.PictureBox resimKutu35;
        private System.Windows.Forms.PictureBox resimKutu20;
        private System.Windows.Forms.PictureBox resimKutu34;
        private System.Windows.Forms.PictureBox resimKutu21;
        private System.Windows.Forms.PictureBox resimKutu33;
        private System.Windows.Forms.PictureBox resimKutu22;
        private System.Windows.Forms.PictureBox resimKutu32;
        private System.Windows.Forms.PictureBox resimKutu23;
        private System.Windows.Forms.PictureBox resimKutu31;
        private System.Windows.Forms.PictureBox resimKutu24;
        private System.Windows.Forms.PictureBox resimKutu30;
        private System.Windows.Forms.PictureBox resimKutu25;
        private System.Windows.Forms.PictureBox resimKutu29;
        private System.Windows.Forms.PictureBox resimKutu26;
        private System.Windows.Forms.PictureBox resimKutu28;
        private System.Windows.Forms.PictureBox resimKutu27;
        private System.Windows.Forms.PictureBox resimKutu39;
        private System.Windows.Forms.PictureBox resimKutu41;
        private System.Windows.Forms.PictureBox resimKutu47;
        private System.Windows.Forms.PictureBox resimKutu49;
        private System.Windows.Forms.PictureBox resimKutu127;
        private System.Windows.Forms.PictureBox resimKutu125;
        private System.Windows.Forms.PictureBox resimKutu120;
        private System.Windows.Forms.PictureBox resimKutu115;
        private System.Windows.Forms.PictureBox resimKutu116;
        private System.Windows.Forms.PictureBox resimKutu113;
        private System.Windows.Forms.PictureBox resimKutu128;
        private System.Windows.Forms.PictureBox resimKutu114;
        private System.Windows.Forms.PictureBox resimKutu117;
        private System.Windows.Forms.PictureBox resimKutu118;
        private System.Windows.Forms.PictureBox resimKutu119;
        private System.Windows.Forms.PictureBox resimKutu121;
        private System.Windows.Forms.PictureBox resimKutu123;
        private System.Windows.Forms.PictureBox resimKutu122;
        private System.Windows.Forms.PictureBox resimKutu124;
        private System.Windows.Forms.PictureBox resimKutu126;
        private System.Windows.Forms.PictureBox resimKutu55;
        private System.Windows.Forms.PictureBox resimKutu56;
        private System.Windows.Forms.PictureBox resimKutu57;
        private System.Windows.Forms.PictureBox resimKutu58;
        private System.Windows.Forms.PictureBox resimKutu59;
        private System.Windows.Forms.PictureBox resimKutu60;
        private System.Windows.Forms.PictureBox resimKutu61;
        private System.Windows.Forms.PictureBox resimKutu62;
        private System.Windows.Forms.PictureBox resimKutu63;
        private System.Windows.Forms.PictureBox resimKutu64;
        private System.Windows.Forms.PictureBox resimKutu65;
        private System.Windows.Forms.PictureBox resimKutu66;
        private System.Windows.Forms.PictureBox resimKutu67;
        private System.Windows.Forms.PictureBox resimKutu68;
        private System.Windows.Forms.PictureBox resimKutu69;
        private System.Windows.Forms.PictureBox resimKutu70;
        private System.Windows.Forms.PictureBox resimKutu71;
        private System.Windows.Forms.PictureBox resimKutu72;
        private System.Windows.Forms.PictureBox resimKutu73;
        private System.Windows.Forms.PictureBox resimKutu74;
        private System.Windows.Forms.PictureBox resimKutu75;
        private System.Windows.Forms.PictureBox resimKutu76;
        private System.Windows.Forms.PictureBox resimKutu77;
        private System.Windows.Forms.PictureBox resimKutu78;
        private System.Windows.Forms.PictureBox resimKutu79;
        private System.Windows.Forms.PictureBox resimKutu80;
        private System.Windows.Forms.PictureBox resimKutu81;
        private System.Windows.Forms.PictureBox resimKutu82;
        private System.Windows.Forms.PictureBox resimKutu83;
        private System.Windows.Forms.PictureBox resimKutu84;
        private System.Windows.Forms.PictureBox resimKutu85;
        private System.Windows.Forms.PictureBox resimKutu86;
        private System.Windows.Forms.PictureBox resimKutu87;
        private System.Windows.Forms.PictureBox resimKutu88;
        private System.Windows.Forms.PictureBox resimKutu89;
        private System.Windows.Forms.PictureBox resimKutu90;
        private System.Windows.Forms.PictureBox resimKutu91;
        private System.Windows.Forms.PictureBox resimKutu92;
        private System.Windows.Forms.PictureBox resimKutu93;
        private System.Windows.Forms.PictureBox resimKutu94;
        private System.Windows.Forms.PictureBox resimKutu95;
        private System.Windows.Forms.PictureBox resimKutu96;
        private System.Windows.Forms.PictureBox resimKutu97;
        private System.Windows.Forms.PictureBox resimKutu98;
        private System.Windows.Forms.PictureBox resimKutu99;
        private System.Windows.Forms.PictureBox resimKutu100;
        private System.Windows.Forms.PictureBox resimKutu101;
        private System.Windows.Forms.PictureBox resimKutu102;
        private System.Windows.Forms.PictureBox resimKutu103;
        private System.Windows.Forms.PictureBox resimKutu104;
        private System.Windows.Forms.PictureBox resimKutu105;
        private System.Windows.Forms.PictureBox resimKutu106;
        private System.Windows.Forms.PictureBox resimKutu107;
        private System.Windows.Forms.PictureBox resimKutu108;
        private System.Windows.Forms.PictureBox resimKutu109;
        private System.Windows.Forms.PictureBox resimKutu110;
        private System.Windows.Forms.PictureBox resimKutu111;
        private System.Windows.Forms.PictureBox resimKutu112;
        private System.Windows.Forms.PictureBox resimKutu134;
        private System.Windows.Forms.PictureBox resimKutu133;
        private System.Windows.Forms.PictureBox resimKutu136;
        private System.Windows.Forms.PictureBox resimKutu135;
        private System.Windows.Forms.PictureBox resimKutu130;
        private System.Windows.Forms.PictureBox resimKutu129;
        private System.Windows.Forms.PictureBox resimKutu132;
        private System.Windows.Forms.PictureBox resimKutu131;
        private System.Windows.Forms.PictureBox resimKutu142;
        private System.Windows.Forms.PictureBox resimKutu141;
        private System.Windows.Forms.PictureBox resimKutu144;
        private System.Windows.Forms.PictureBox resimKutu143;
        private System.Windows.Forms.PictureBox resimKutu138;
        private System.Windows.Forms.PictureBox resimKutu137;
        private System.Windows.Forms.PictureBox resimKutu140;
        private System.Windows.Forms.PictureBox resimKutu139;
    }
}