﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev
{
    public partial class Giris : Form
    {

        public Giris()

        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            yuklemeTimer.Start();
            ilerlemeCubugu.Value = 0;
        }
        
        private void yuklemeTimer_Tick(object sender, EventArgs e)
        {
            
            ilerlemeCubugu.Value += 2;
            ilerlemeYazi.Text = ilerlemeCubugu.Value.ToString();
            if (ilerlemeCubugu.Value == 100)
            {
                yuklemeTimer.Stop();
                anaForm frm = new anaForm();
                frm.Show();
                this.Hide();
            }
            
        }

        private void ilerlemeYazi_Click(object sender, EventArgs e)
        {

        }
    }
}
